/**
* \file
*
* \brief $safeprojectname$ ATxmega32A4U board template
*
*/

/*
* Include header files for all drivers that have been imported from
* Atmel Software Framework (ASF).
*/
#include <asf.h>

int main (void)
{
	ioport_init();
	board_init();

	// Power on LED on board
	ioport_set_pin_level(LED0_GPIO, IOPORT_PIN_LEVEL_HIGH);
	ioport_set_pin_level(LED1_GPIO, IOPORT_PIN_LEVEL_HIGH);
	ioport_set_pin_level(LED2_GPIO, IOPORT_PIN_LEVEL_HIGH);
		
	while(true)
	{
		// Insert application code here, after the board has been initialized.
	}
}
