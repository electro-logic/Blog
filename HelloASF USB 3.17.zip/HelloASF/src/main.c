#include <asf.h>

int main (void)
{
	ioport_init();
	board_init();
	sysclk_init();
	
	irq_initialize_vectors();
	cpu_irq_enable();
	
	stdio_usb_init();

	while(true)
	{
		printf("Hello USB\r\n");
		delay_s(1);
	}
}
