/**
 * \file
 *
 * \brief User board configuration template
 *
 */

#ifndef CONF_BOARD_H_
#define CONF_BOARD_H_





#endif /* CONF_BOARD_H_ */