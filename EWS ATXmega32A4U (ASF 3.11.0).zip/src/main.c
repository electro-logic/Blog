/**
* \file
*
* \brief $safeprojectname$ ATxmega32A4U board template
*
*/

#include <asf.h>

int main(void)
{
	ioport_init();
	board_init();

	// Power on LED on board
	ioport_set_pin_level(GPIO_LED_RED, IOPORT_PIN_LEVEL_HIGH);
	ioport_set_pin_level(GPIO_LED_GREEN, IOPORT_PIN_LEVEL_HIGH);
	ioport_set_pin_level(GPIO_LED_YELLOW, IOPORT_PIN_LEVEL_HIGH);

    while(true)
    {
        //TODO:: Please write your application code 
    }
}