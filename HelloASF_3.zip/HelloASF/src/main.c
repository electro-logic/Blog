#include <asf.h>

int main (void)
{
	ioport_init();
	board_init();
	
	sysclk_init();
	// delay_init()	There is no need to call it, is deprecated
	
	// Power on LED on board
	ioport_set_pin_level(LED0_GPIO, IOPORT_PIN_LEVEL_HIGH);
	ioport_set_pin_level(LED1_GPIO, IOPORT_PIN_LEVEL_HIGH);
	ioport_set_pin_level(LED2_GPIO, IOPORT_PIN_LEVEL_HIGH);
	
	while(true)
	{
		ioport_set_pin_level(LED0_GPIO, IOPORT_PIN_LEVEL_LOW);
		delay_s(1);
		ioport_set_pin_level(LED0_GPIO, IOPORT_PIN_LEVEL_HIGH);
		delay_s(1);
	}
}
