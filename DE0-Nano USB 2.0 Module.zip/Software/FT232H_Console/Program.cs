﻿// See http://electro-logic.blogspot.it for updates and the article related to this code

using System;
using System.Threading;
using System.IO;
using System.Diagnostics;
using FTD2XX_NET;

namespace FT232H_Console
{
  class Program
  {
    const double MB = 1048576.0;
    const double KB = 1024.0;

    static void Main(string[] args)
    {
      string fileRead = "dataIn.bin";     // TODO: Set with file to read
      string fileWrite = "dataOut.bin";   // TODO: Set with file to write

      byte latency = 1;                   // default is 16ms, set to 1ms for better performance
      uint bufferSize = 2048*8;           // computer buffer (eight times device buffer)

      FTDI ft232h = new FTDI();
      FTDI.FT_STATUS ftStatus;

      ftStatus = ft232h.OpenByDescription("UM232H");
      if (ftStatus != FTDI.FT_STATUS.FT_OK)
      {
        Console.WriteLine("Failed to open device (error {0})", ftStatus);
        return;
      }

      uint deviceID = 0;
      ftStatus = ft232h.GetDeviceID(ref deviceID);
      if (ftStatus != FTDI.FT_STATUS.FT_OK)
      {
        Console.WriteLine("Failed to get Device ID (error {0})", ftStatus);
        return;
      }

      Console.WriteLine("Open Device ID: {0}", deviceID.ToString("X"));

      ftStatus = ft232h.SetBitMode(0xFF, FTD2XX_NET.FTDI.FT_BIT_MODES.FT_BIT_MODE_RESET);
      if (ftStatus != FTDI.FT_STATUS.FT_OK)
      {
        Console.WriteLine("Failed to SetBitMode in reset mode (error {0})", ftStatus);
        ft232h.Close();
        return;
      }

      Thread.Sleep(10);

      ftStatus = ft232h.SetBitMode(0xFF, FTD2XX_NET.FTDI.FT_BIT_MODES.FT_BIT_MODE_SYNC_FIFO);
      if (ftStatus != FTDI.FT_STATUS.FT_OK)
      {
        Console.WriteLine("Failed to SetBitMode in 245 Sync FIFO mode (error {0})", ftStatus);
        ft232h.Close();
        return;
      }

      ftStatus = ft232h.SetLatency(latency);
      if (ftStatus != FTDI.FT_STATUS.FT_OK)
      {
        Console.WriteLine("Failed to SetLatency (error {0})", ftStatus);
        ft232h.Close();
        return;
      }

      ftStatus = ft232h.InTransferSize(0x10000);    // Default TransferSize is 4k, 0x10000=65k
      if (ftStatus != FTDI.FT_STATUS.FT_OK)
      {
        Console.WriteLine("Failed to change InTransferSize (error {0})", ftStatus);
        ft232h.Close();
        return;
      }

      ftStatus = ft232h.SetFlowControl(FTD2XX_NET.FTDI.FT_FLOW_CONTROL.FT_FLOW_RTS_CTS, 0, 0);
      if (ftStatus != FTDI.FT_STATUS.FT_OK)
      {
        Console.WriteLine("Failed to SetFlowControl with FT_FLOW_RTS_CTS type (error {0})", ftStatus);
        ft232h.Close();
        return;
      }

      FileStream readFile;
      long readFileLenght;
      try
      {
        readFile = File.OpenRead(fileRead);
        readFileLenght = readFile.Length;
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error reading file: \r\n {0}", ex);
        ft232h.Close();
        return;
      }

      Console.WriteLine("File size: {0}", Math.Round(readFileLenght / MB, 3));

      FileStream writeFile;
      try
      {
        File.Delete(fileWrite);
        writeFile = File.OpenWrite(fileWrite);
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error writing file: \r\n {0}", ex);
        ft232h.Close();
        return;
      }

      uint numBytesWritten = 0, numBytesRead = 0;
      int numFileBytesRead = 1;

      byte[] readFileDataBuffer = new byte[bufferSize];
      byte[] readDeviceDataBuffer = new byte[bufferSize];

      long totBytesTransferred = 0;
      long totBytesRead = 0;
      long totBytesWrite = 0;
      long totErrors = 0;
      double errorPercent = 0.0;
      long totFileRead = 0;
      long totBytesProcessed = 0;
      Stopwatch swRead = new Stopwatch();
      Stopwatch swWrite = new Stopwatch();

      while (numFileBytesRead > 0)
      {
        readFileDataBuffer = new byte[bufferSize];  // Clear buffer

        try
        {
          numFileBytesRead = readFile.Read(readFileDataBuffer, 0, (int)bufferSize);      // Read file block
        }
        catch (Exception ex)
        {
          Console.WriteLine("Error reading file: \r\n {0}", ex);
          ft232h.Close();
          return;
        }

        totFileRead += numFileBytesRead;

        // Keep time for write operations
        swWrite.Start();
        // Write to device the read file block
        ftStatus = ft232h.Write(readFileDataBuffer, bufferSize, ref numBytesWritten);
        swWrite.Stop();

        if (ftStatus != FTDI.FT_STATUS.FT_OK)
        {
          Console.WriteLine("Failed to Write device (error {0})", ftStatus);
          ft232h.Close();
          return;
        }

        // Keep time for read operations 
        swRead.Start();
        // Read from device next file block
        ftStatus = ft232h.Read(readDeviceDataBuffer, bufferSize, ref numBytesRead);
        swRead.Stop();

        if (ftStatus != FTDI.FT_STATUS.FT_OK)
        {
          Console.WriteLine("Failed to Read device (error {0})", ftStatus);
          ft232h.Close();
          return;
        }

        totBytesRead += numBytesRead;
        totBytesWrite += numBytesWritten;
        totBytesTransferred = totBytesRead + totBytesWrite;

        try
        {
            writeFile.Write(readDeviceDataBuffer, 0, numFileBytesRead);   // Write file block
        }
        catch (Exception ex)
        {
          Console.WriteLine("Error writing file: \r\n {0}", ex);
          ft232h.Close();
          return;
        }

        // Check if read byte are equals to write byte
        for (int i = 0; i < readFileDataBuffer.Length; i++)
        {
          totBytesProcessed++;

          if (readFileDataBuffer[i] != readDeviceDataBuffer[i])
          {
            totErrors++;
            errorPercent = (totErrors * 100.0 / (double)totBytesProcessed);

            // Create binary string of bad and right value
            string badValBin = Convert.ToString(readDeviceDataBuffer[i], 2).PadLeft(8, '0');
            string rightValBin = Convert.ToString(readFileDataBuffer[i], 2).PadLeft(8, '0');

            // Get different bits
            string binaryComp = HelperUtility.BinaryBitCompare(badValBin, rightValBin);

            //Console.WriteLine("Data error at byte #{0}: bit {1} mismatch. {2} instead of {3} \r\n",
            //      totBytesRead - numBytesRead + i + 1, binaryComp, badValBin, rightValBin);            
          }
        }

        // Update statistics
        if ((totBytesTransferred % (65 * KB)) == 0) // Update every 65KB
        {
          double elapsedWriteSeconds = swWrite.ElapsedMilliseconds / 1000.0;
          double writeSpeed = (totBytesWrite / elapsedWriteSeconds) / MB;

          double elapsedReadSeconds = swRead.ElapsedMilliseconds / 1000.0;
          double readSpeed = (totBytesRead / elapsedReadSeconds) / MB;

          double elapsedSeconds = elapsedWriteSeconds + elapsedReadSeconds;
          double avgSpeed = (totBytesTransferred / elapsedSeconds) / MB;

          double progress = totFileRead * 100 / readFileLenght;

          Console.Clear();
          Console.WriteLine("Progress:\t {0}%", progress);
          Console.WriteLine("Read Speed:\t {0} MB/s", Math.Round(readSpeed, 3));
          Console.WriteLine("Write Speed:\t {0} MB/s", Math.Round(writeSpeed, 3));
          Console.WriteLine("Average Speed:\t {0} MB/s", Math.Round(avgSpeed, 3));
          Console.WriteLine("Errors:\t {0} ({1}%)", totErrors, Math.Round(errorPercent, 5));
        }
      }

      try
      {
        readFile.Close();
        writeFile.Close();
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error closing files: \r\n {0}", ex);
      }

      ftStatus = ft232h.Close();
      if (ftStatus != FTDI.FT_STATUS.FT_OK)
      {
        Console.WriteLine("Failed to Close device (error {0})", ftStatus);
        return;
      }
    }
  }
}
