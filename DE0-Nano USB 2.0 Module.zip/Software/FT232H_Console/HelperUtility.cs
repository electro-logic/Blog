﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public static class HelperUtility
{
  /// <summary>
  /// Compare strings of 8 bit and return different bit 
  /// </summary>        
  public static string BinaryBitCompare(string s1, string s2)
  {
    string result = string.Empty;
    for (int i = 0; i < 8; i++)
    {
      if (s1[i] != s2[i])
      {
        result += (8 - i).ToString() + ",";
      }
    }
    return result.Remove(result.Length - 1, 1);
  }
}